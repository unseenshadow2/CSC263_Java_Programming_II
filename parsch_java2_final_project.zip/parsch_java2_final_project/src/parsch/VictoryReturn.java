package parsch;

/**
 * Created by unseenshadow2 on 12/4/2016.
 */
public enum VictoryReturn
{
    Win, Lose, Continue;
}
